#!/bin/bash
node .
